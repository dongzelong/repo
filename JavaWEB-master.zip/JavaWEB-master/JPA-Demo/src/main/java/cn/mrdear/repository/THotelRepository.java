package cn.mrdear.repository;

/**
 * @author Niu Li
 * @date 2017/1/7
 */
public interface THotelRepository {
}
