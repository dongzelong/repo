package cn.mrdear.conf;

import org.springframework.context.annotation.Configuration;

/**
 * 定义一些servlet使用
 * @author Niu Li
 * @date 2016/8/13
 */
@Configuration
public class ServletConfig {

}
