package cn.mrdear.mapper;

import cn.mrdear.entity.Book;
import tk.mybatis.mapper.common.Mapper;

public interface BookMapper extends Mapper<Book> {

}