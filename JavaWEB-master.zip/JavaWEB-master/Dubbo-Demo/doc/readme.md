
1. 启动需要先下载zk,然后启动
2. Provider中spring配置文件host改成本机ip地址,然后启动
3. 启动Consumer
4. 可下载Simple-monitor   http://download.csdn.net/detail/liweifengwf/7864009
5. 可下载dubbo-admin    http://download.csdn.net/detail/leiyong0326/9548973
6. dubbo的调用基本就是这样,大多数规则都可以在admin中配置也可以在spring注册服务和引用的时候配置