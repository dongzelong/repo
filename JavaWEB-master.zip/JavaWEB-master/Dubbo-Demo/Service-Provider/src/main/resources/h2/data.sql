INSERT INTO user (username, password, age, nickname, mail, memo) VALUES ('zhangsan',
 '123456', 18, '张三', '1111@qq.com', 'hahahah');
INSERT INTO user (username, password, age, nickname, mail, memo) VALUES ('lis',
'123456', 19, '李四', '123131@qq.com', 'xixiixxi');
INSERT INTO user (username, password, age, nickname, mail, memo) VALUES ('wanger',
'123456', 29, '王二', '12131984@qq.com', 'dqdh');