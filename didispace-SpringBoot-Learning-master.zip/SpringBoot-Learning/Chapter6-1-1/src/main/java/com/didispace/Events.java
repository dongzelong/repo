package com.didispace;

public enum Events {
    PAY,        // 支付
    RECEIVE     // 收货
}